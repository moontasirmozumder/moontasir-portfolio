package com.moontasir.bustracker

import android.os.Bundle
import android.preference.PreferenceManager
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.moontasir.bustracker.databinding.ActivityMainBinding
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var busMarker: Marker

    private var firstLoad = true
    private var followBus = true

    // Default location: Dhaka (same as the web version's initial map center)
    private val defaultLat = 23.8103
    private val defaultLng = 90.4125

    override fun onCreate(savedInstanceState: Bundle?) {
        // osmdroid requires its config to be loaded before setContentView
        Configuration.getInstance().load(
            this,
            PreferenceManager.getDefaultSharedPreferences(this)
        )

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupButtons()
        listenToFirebase()
    }

    private fun setupMap() {
        binding.map.setTileSource(TileSourceFactory.MAPNIK)
        binding.map.setMultiTouchControls(true)
        binding.map.controller.setZoom(13.0)
        binding.map.controller.setCenter(GeoPoint(defaultLat, defaultLng))

        busMarker = Marker(binding.map).apply {
            position = GeoPoint(defaultLat, defaultLng)
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            icon = getDrawable(R.drawable.ic_bus_marker)
            title = "BUS-01"
        }
        binding.map.overlays.add(busMarker)
    }

    private fun setupButtons() {
        binding.followBtn.setOnClickListener {
            followBus = !followBus
            binding.followBtn.text = if (followBus) "Follow Bus : ON" else "Follow Bus : OFF"
        }

        binding.centerBtn.setOnClickListener {
            binding.map.controller.animateTo(busMarker.position)
            binding.map.controller.setZoom(17.0)
        }
    }

    private fun listenToFirebase() {
        val busRef = FirebaseDatabase.getInstance().getReference("bus")

        busRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val bus = snapshot.getValue(BusData::class.java) ?: run {
                    android.util.Log.d("BusTracker", "No bus data found")
                    return
                }

                if (bus.latitude == 0.0 && bus.longitude == 0.0) return

                val point = GeoPoint(bus.latitude, bus.longitude)

                // ===== Update info card =====
                binding.busId.text = bus.id
                binding.latitude.text = String.format(Locale.US, "%.6f", bus.latitude)
                binding.longitude.text = String.format(Locale.US, "%.6f", bus.longitude)
                binding.speed.text = "${bus.speed} km/h"

                if (bus.status == "online") {
                    binding.statusText.text = "Online"
                    binding.statusText.setTextColor(android.graphics.Color.parseColor("#16a34a"))
                } else {
                    binding.statusText.text = "Offline"
                    binding.statusText.setTextColor(android.graphics.Color.parseColor("#dc2626"))
                }

                if (bus.lastUpdate > 0) {
                    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault())
                    binding.lastUpdate.text = sdf.format(Date(bus.lastUpdate.toLong()))
                }

                // ===== Update marker + map =====
                busMarker.position = point
                busMarker.title = "${bus.id}\nSpeed: ${bus.speed} km/h"
                binding.map.invalidate()

                if (followBus) {
                    binding.map.controller.animateTo(point)
                }

                if (firstLoad) {
                    binding.map.controller.setZoom(17.0)
                    binding.map.controller.setCenter(point)
                    firstLoad = false
                }
            }

            override fun onCancelled(error: DatabaseError) {
                android.util.Log.e("BusTracker", "Firebase read failed: ${error.message}")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        binding.map.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.map.onPause()
    }
}
