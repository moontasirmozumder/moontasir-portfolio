package com.moontasir.bustracker

/**
 * Mirrors the JSON structure written by the ESP32 to Firebase:
 * { id, latitude, longitude, speed, status, lastUpdate }
 * No-arg constructor is required for Firebase's automatic deserialization.
 */
data class BusData(
    var id: String = "BUS-01",
    var latitude: Double = 0.0,
    var longitude: Double = 0.0,
    var speed: Double = 0.0,
    var status: String = "offline",
    // Stored as a number (double) by the ESP32, so keep it Double here to avoid
    // a Firebase deserialization crash, then convert to Long only when needed.
    var lastUpdate: Double = 0.0
)
